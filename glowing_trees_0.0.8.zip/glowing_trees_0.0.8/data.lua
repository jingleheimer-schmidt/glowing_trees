local tree_glow = {
    type = "sprite",
    name = "tree_glow",
    filename = "__glowing_trees__/source_media/tiny_pngs/frame_count_1/glow_1.png",
    priority = "high",
    width = 51,
    height = 52,
    scale = 1,
}

data:extend({
    tree_glow
})
